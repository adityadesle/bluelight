import React from 'react'
import "./Navbar.css";

export const Navbar = () => {
  return (

            <div className='nav container-fluid col-xl-9 col-lg-11'>
                    <div>
                        <span>Logo</span>
                    </div>
                    <div className='heads'>
                        <span>Home</span>
                        <span>AboutUs</span>
                        <span>ContactUs</span>
                        {/* <button className='join-btn'>Join</button> */}
                    </div>
                    <div>
                      <span>Profile</span>
                    </div>
            </div>
      
  )
}
