import React from 'react'
import { Navbar } from '../Navbar/Navbar'

export const Home = () => {
  return (
      <Navbar/>
  )
}
